// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'current_song_notifier.dart';

// **************************************************************************
// RiverpodGenerator
// **************************************************************************

String _$currentSongNotifierHash() =>
    r'451f625f52f5a883c5287a8d94ca91cc8f6398a6';

/// See also [CurrentSongNotifier].
@ProviderFor(CurrentSongNotifier)
final currentSongNotifierProvider =
    AutoDisposeNotifierProvider<CurrentSongNotifier, SongModel?>.internal(
  CurrentSongNotifier.new,
  name: r'currentSongNotifierProvider',
  debugGetCreateSourceHash: const bool.fromEnvironment('dart.vm.product')
      ? null
      : _$currentSongNotifierHash,
  dependencies: null,
  allTransitiveDependencies: null,
);

typedef _$CurrentSongNotifier = AutoDisposeNotifier<SongModel?>;
// ignore_for_file: type=lint
// ignore_for_file: subtype_of_sealed_class, invalid_use_of_internal_member, invalid_use_of_visible_for_testing_member
