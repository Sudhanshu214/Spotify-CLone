// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'auth_remote_repository.dart';

// **************************************************************************
// RiverpodGenerator
// **************************************************************************

String _$authRemoteRepositoryHash() =>
    r'd4d3598d49a62c6eddebf6bb77f2fa5eeca4809c';

/// See also [authRemoteRepository].
@ProviderFor(authRemoteRepository)
final authRemoteRepositoryProvider =
    AutoDisposeProvider<AuthRemoteRepository>.internal(
  authRemoteRepository,
  name: r'authRemoteRepositoryProvider',
  debugGetCreateSourceHash: const bool.fromEnvironment('dart.vm.product')
      ? null
      : _$authRemoteRepositoryHash,
  dependencies: null,
  allTransitiveDependencies: null,
);

typedef AuthRemoteRepositoryRef = AutoDisposeProviderRef<AuthRemoteRepository>;
// ignore_for_file: type=lint
// ignore_for_file: subtype_of_sealed_class, invalid_use_of_internal_member, invalid_use_of_visible_for_testing_member
