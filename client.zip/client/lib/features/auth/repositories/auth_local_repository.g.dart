// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'auth_local_repository.dart';

// **************************************************************************
// RiverpodGenerator
// **************************************************************************

String _$authLocalRepositoryHash() =>
    r'2796c8fd85db5fdbcd855413bdb1541a0228e0ad';

/// See also [authLocalRepository].
@ProviderFor(authLocalRepository)
final authLocalRepositoryProvider = Provider<AuthLocalRepository>.internal(
  authLocalRepository,
  name: r'authLocalRepositoryProvider',
  debugGetCreateSourceHash: const bool.fromEnvironment('dart.vm.product')
      ? null
      : _$authLocalRepositoryHash,
  dependencies: null,
  allTransitiveDependencies: null,
);

typedef AuthLocalRepositoryRef = ProviderRef<AuthLocalRepository>;
// ignore_for_file: type=lint
// ignore_for_file: subtype_of_sealed_class, invalid_use_of_internal_member, invalid_use_of_visible_for_testing_member
