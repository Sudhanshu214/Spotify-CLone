// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'home_local_repository.dart';

// **************************************************************************
// RiverpodGenerator
// **************************************************************************

String _$homeLocalRepositoryHash() =>
    r'30806b3c6a6c707b0b46e1f3406f89fd82b550dc';

/// See also [homeLocalRepository].
@ProviderFor(homeLocalRepository)
final homeLocalRepositoryProvider =
    AutoDisposeProvider<HomeLocalRepository>.internal(
  homeLocalRepository,
  name: r'homeLocalRepositoryProvider',
  debugGetCreateSourceHash: const bool.fromEnvironment('dart.vm.product')
      ? null
      : _$homeLocalRepositoryHash,
  dependencies: null,
  allTransitiveDependencies: null,
);

typedef HomeLocalRepositoryRef = AutoDisposeProviderRef<HomeLocalRepository>;
// ignore_for_file: type=lint
// ignore_for_file: subtype_of_sealed_class, invalid_use_of_internal_member, invalid_use_of_visible_for_testing_member
